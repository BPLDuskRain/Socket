gcc server.c -o s
gcc client.c -o c
