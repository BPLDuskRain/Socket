# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <errno.h>

int main(int argc, char* argv[]){
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd == -1){
        perror("socket");
        return -1;
    }
    printf("socket created\n");

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = (in_port_t)htons((uint16_t)atoi(argv[2]));
    int pton = inet_pton(AF_INET, argv[1], &(addr.sin_addr.s_addr));
    if(pton != 1){
        perror("pton");
        return -1;
    }

    int binder = bind(fd, (struct sockaddr* )&addr, (socklen_t)sizeof(addr));
    if(binder == -1){
        perror("bind");
        return -1;
    }
    printf("socket binded\n");

    int listener = listen(fd, 2);
    if(listener == -1){
        perror("listen");
        return -1;
    }
    printf("start listen\n");

    while(1){
        struct sockaddr_in caddr;
        socklen_t caddrlen = sizeof(caddr);
        int confd = accept(fd, (struct sockaddr*)&caddr, &caddrlen);
        if(confd == -1){
            perror("connect");
        }
        char *cip = inet_ntoa(caddr.sin_addr);
        short cport = ntohs(caddr.sin_port);
        printf("connected to client [%s:%hu]\n", cip, cport);

        int pid = fork();
        
        while(pid == 0){
            char buf[100] = {0};
            int recvmsg = recv(confd, buf, sizeof(buf), 0);
            if(recvmsg <= 0){
                if(recvmsg == 0){
                    perror("disconnect");
                    break;
                }
                if(recvmsg == -1){
                    perror("recv failed");
                    break;
                }
            }
            printf("recv: %s form %hu\n", buf, cport);
            if(strcmp(buf, "exit") == 0){
                printf("process %hu exit\n", getpid());
                int closer = close(confd);
                if(closer == -1){
                    perror("close confd");
                    return -1;
                }
                exit(0);
            }
        }
        printf("create process %d\n", pid);
    }
    int closer = close(fd);
    if(closer == -1){
        perror("close fd");
        return -1;
    }
    return 0;
}