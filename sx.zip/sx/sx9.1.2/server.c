# include <stdio.h>
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/select.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <errno.h>

int main(int argc, char* argv[]){
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd == -1){
        perror("socket");
        return -1;
    }
    printf("socket created\n");

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = (in_port_t)htons((uint16_t)atoi(argv[2]));
    int pton = inet_pton(AF_INET, argv[1], &(addr.sin_addr.s_addr));
    if(pton != 1){
        perror("pton");
        return -1;
    }

    int binder = bind(fd, (struct sockaddr* )&addr, (socklen_t)sizeof(addr));
    if(binder == -1){
        perror("bind");
        return -1;
    }
    printf("socket binded\n");

    int listener = listen(fd, 2);
    if(listener == -1){
        perror("listen");
        return -1;
    }
    printf("start listen\n");

    fd_set fdset;
    int confd[1024] = {0};
    struct timeval tv = {0,0};
    int count = 0;
    for(int i = 0; ; ){
        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);
        int res = select(1024, &fdset, NULL, NULL, &tv);
        if(res > 0){
            if(FD_ISSET(fd, &fdset)){
                struct sockaddr_in caddr;
                socklen_t caddrlen = sizeof(caddr);
                confd[i] = accept(fd, (struct sockaddr*)&caddr, &caddrlen);
                if(confd[i] == -1){
                    perror("connect");
                }
                i = (i + 1) % 1024;
                count++;
                char *cip = inet_ntoa(caddr.sin_addr);
                short cport = ntohs(caddr.sin_port);
                // printf("connected to client [%s:%hu]\n", cip, cport);
                // printf("client num: %d\n", count);
            }
        }

        FD_ZERO(&fdset);
        for(int j = 0; j < i; j++){
            if(confd[j] == -1) continue;
            FD_SET(confd[j], &fdset);
        }
        int res2 = select(1024, NULL, &fdset, NULL, &tv);
        // printf("%d messages\n", res2);

        if(res2 > 0){
            for(int j = 0; j < i; j++){
                if(confd[j] == -1 || FD_ISSET(confd[j], &fdset) != 1){
                    continue;
                }
                char buf[1024] = {0};
                // int recvmsg = recv(confd[j], buf, sizeof(buf), 0);
                // if(recvmsg <= 0){
                //     if(recvmsg == 0){
                //         perror("disconnect");
                //         break;
                //     }
                //     if(recvmsg == -1){
                //         perror("recv failed");
                //         break;
                //     }
                // }
                // printf("recv: %s from fd[%d]\n", buf, j);
                // if(strcmp(buf, "exit") == 0){
                //     printf("fd[%d] exit\n", j);
                //     int closer = close(confd[j]);
                //     confd[j] = -1;
                //     count--;
                //     printf("client num: %d\n", count);
                //     if(closer == -1){
                //         perror("close confd");
                //         return -1;
                //     }
                //     break;
                // }
                int sendmsg = send(confd[j], buf, sizeof(buf), 0);
                if(sendmsg == -1){
                    perror("sendmsg");
                    break;
                }
            }
        }
    }
    int closer = close(fd);
    if(closer == -1){
        perror("close fd");
        return -1;
    }
    return 0;
}