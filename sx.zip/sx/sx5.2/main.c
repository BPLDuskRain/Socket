# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <pthread.h>
# include <errno.h>
# include <semaphore.h>

#define NUM 5

int chopstick[NUM];
pthread_t id[NUM];
pthread_t tid[NUM];

void think(pthread_t id){
    printf("philosopher %ld start thinking\n", id);
    srand(tid[id]);
    sleep(rand()%5);
    printf("philosopher %ld finish thinking\n", id);
}

void getChopstick1(pthread_t id){
    int l = -1;
    int r = -1;
    while(1){
        if(l == -1){
            printf("\t\tsphilosopher %ld want to GOT chopstick[%ld]\n", id, id);
            l = sem_trywait(&(chopstick[id]));
        }
        else{
            printf("\t\tphilosopher %ld want to GOT chopstick[%ld]\n", id, (id+1)%NUM);
            int r = sem_trywait(&(chopstick[(id+1)%NUM]));
            if(l == 0 && r == 0){
                break;
            }
        }
        
    }
}

void getChopstick2(pthread_t id){
    while(1){
        if(sem_trywait(&(chopstick[id])) == 0){
            printf("\tphilosopher %ld GOT chopstick[%ld]\n", id, id);
        }
        else{
            continue;
        }
        if(sem_trywait(&(chopstick[(id+1)%NUM])) == EAGAIN){
            sem_post(&(chopstick[id]));
            printf("\tphilosopher %ld GIVEUP chopstick[%ld]\n", id, id);
            sleep(1);
        }
        else{
            printf("\tphilosopher %ld GOT chopstick[%ld]\n", id, (id+1)%NUM);
            break;
        }
    }
}

void eat(pthread_t id){
    printf("\t\tphilosopher %ld start EATing\n", id);
    sleep(1);
    printf("\t\tphilosopher %ld finish EATing\n", id);
}

void giveupAll(pthread_t id){
    sem_post(&(chopstick[id]));
    printf("\tphilosopher %ld GIVEUP chopstick[%ld]\n", id, id);
    sem_post(&(chopstick[(id+1)%NUM]));
    printf("\tphilosopher %ld GIVEUP chopstick[%ld]\n", id, (id+1)%NUM);
}

void* thread_func(pthread_t id){
    pthread_t tid = pthread_self();
    think(id);
    getChopstick1(id);
    eat(id);
    giveupAll(id);

    printf("philosopher %ld exit\n", id);
    pthread_exit(NULL);
}

int main(){
    for(int i = 0; i < NUM; i++){
        id[i] = i;
    }

    for(int i = 0; i < NUM; i++){
        sem_init(&(chopstick[i]), 0, 1);
    }

    for(int i = 0; i < NUM; i++){
        pthread_create(&(tid[i]), NULL, thread_func, id[i]);
    }

    for(int i = 0; i < NUM; i++){
        pthread_join(tid[i], NULL);
        printf("destroy %d\n", i);
    }

    for(int i = 0; i < NUM; i++){
        sem_destroy(&(chopstick[i]));
    }
    
    printf("main exit\n");
    return 0;
}