# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <pthread.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <errno.h>

void* thread_recv(struct sockaddr_in* addr){

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd == -1){
        perror("socket");
        return NULL;
    }
    // printf("socket created\n");

    int connecter = connect(fd, (struct sockaddr*)addr, (socklen_t)sizeof(*addr));
    if(connecter == -1){
        perror("connect");
        return NULL;
    }
    // printf("connected\n");

    // while(1){
    //     char buf[2048] = {0};
    //     // scanf("%s", buf);
    //     int recvmsg = recv(fd, buf, sizeof(buf), 0);
    //     if(recvmsg <= 0){
    //         if(recvmsg == 0){
    //             perror("disconnect");
    //             break;
    //         }
    //         if(recvmsg == -1){
    //             perror("recv failed");
    //             break;
    //         }
    //     }
    //     // printf("recv: %ld bytes\n", sizeof(buf));
    //     // if(strcmp("exit", buf) == 0){
    //     //     printf("exit\n");
    //     //     break;
    //     // }
    // }
    int closer = close(fd);
    if(closer == -1){
        perror("close");
        return NULL;
    }
    pthread_exit(NULL);
}

int main(int argc, char* argv[]){
    
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = (in_port_t)htons((uint16_t)atoi(argv[2]));
    int pton = inet_pton(AF_INET, argv[1], &addr.sin_addr.s_addr);
    if(pton != 1){
        perror("pton");
        return -1;
    }

    int num = atoi(argv[3]);
    pthread_t tid[1024];
    printf("will create %d threads\n", num);

    struct timeval start, end;

    gettimeofday(&start, NULL);

    for(int i = 0; i < num; i++){
        pthread_create(&tid[i], NULL, thread_recv, &addr);
    }

    for(int i = 0; i < num; i++){
        pthread_join(tid[i], NULL);
    }

    gettimeofday(&end, NULL);

    printf("spend %ldus\n", (end.tv_sec-start.tv_sec)*1000*1000+end.tv_usec-start.tv_usec);

    return 0;
}