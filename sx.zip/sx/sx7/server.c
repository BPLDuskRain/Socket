# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <string.h>
# include <pthread.h>
# include <semaphore.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <errno.h>

#define TASK 10

struct threadpool_t{
    pthread_t tid[10];
    pthread_mutex_t mutex;
    sem_t empty;
    sem_t full;
    int task[TASK];
    int read;
};

struct threadpool_t threadpool;
int confd[TASK] = {0};

void threadpool_init();
void taskget();
void recv_unisend(int* fd);
void recv_multisend(int* fd);

int main(int argc, char* argv[]){
    threadpool_init();

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd == -1){
        perror("socket");
        return -1;
    }
    printf("socket created\n");

    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = (in_port_t)htons((uint16_t)atoi(argv[2]));
    int pton = inet_pton(AF_INET, argv[1], &(addr.sin_addr.s_addr));
    if(pton != 1){
        perror("pton");
        return -1;
    }

    int binder = bind(fd, (struct sockaddr* )&addr, (socklen_t)sizeof(addr));
    if(binder == -1){
        perror("bind");
        return -1;
    }
    printf("socket binded\n");

    int listener = listen(fd, 2);
    if(listener == -1){
        perror("listen");
        return -1;
    }
    printf("start listen\n");

    for(int i = 0; ; i++){
        struct sockaddr_in caddr;
        socklen_t caddrlen = sizeof(caddr);
        confd[i%TASK] = accept(fd, (struct sockaddr*)&caddr, &caddrlen);
        if(confd[i%TASK] == -1){
            perror("connect");
        }
        char *cip = inet_ntoa(caddr.sin_addr);
        short cport = ntohs(caddr.sin_port);
        printf("connected to client [%s:%hu]\n", cip, cport);

        sem_wait(&(threadpool.empty));
        pthread_mutex_lock(&(threadpool.mutex));

        threadpool.task[i%TASK] = 2;
        //printf("task[%d] in the queue\n", i%TASK);
        
        pthread_mutex_unlock(&(threadpool.mutex));
        sem_post(&(threadpool.full));
    }
    int closer = close(fd);
    if(closer == -1){
        perror("close fd");
        return -1;
    }

    return 0;
}

void threadpool_init(){
    pthread_mutex_init(&(threadpool.mutex), NULL);
    sem_init(&(threadpool.empty), 0, TASK);
    sem_init(&(threadpool.full), 0, 0);
    memset(threadpool.task, 0, sizeof(threadpool.task));
    threadpool.read = 0;
    for(int i = 0; i < TASK; i++){
        pthread_create(&(threadpool.tid[i]), NULL, taskget, NULL);
    }
}

void taskget(){
    printf("*thread %ld born\n", pthread_self());
    while(1){
        sem_wait(&(threadpool.full));
        pthread_mutex_lock(&(threadpool.mutex));

        int myread = threadpool.read;
        int task = threadpool.task[threadpool.read];

        printf("*thread %ld got task[%d]\n", pthread_self(), threadpool.read);
        threadpool.read = (threadpool.read + 1) % TASK;

        pthread_mutex_unlock(&(threadpool.mutex));
        sem_post(&(threadpool.empty));

        switch(task){
            case 0:
                break;
            case 1:
                recv_unisend(&confd[myread]);
                break;
            case 2:
                recv_multisend(&confd[myread]);
                break;
        }

    }
}

void recv_unisend(int* fd){
    while(1){
        char buf[100] = {0};
        int recvmsg = recv(*fd, buf, sizeof(buf), 0);
        if(recvmsg <= 0){
            if(recvmsg == 0){
                perror("disconnect");
                break;
            }
            if(recvmsg == -1){
                perror("recv failed");
                break;
            }
        }

        if(strcmp(buf, "exit") == 0){
            printf("*thread %ld back to pool for disconnection\n", pthread_self());
            int closer = close(*fd);
            *fd = 0;
            if(closer == -1){
                perror("thread exit");
                exit(-1);
            }
            return;
        }

        printf("*thread %ld recv: %s\n", pthread_self(), buf);
        
        int sendmsg = send(*fd, buf, sizeof(buf), 0);
        if(sendmsg == -1){
            perror("sendmsg");
            break;
        }
    }
}

void recv_multisend(int* fd){
    while(1){
        char buf[100] = {0};
        int recvmsg = recv(*fd, buf, sizeof(buf), 0);
        if(recvmsg <= 0){
            if(recvmsg == 0){
                perror("disconnect");
                break;
            }
            if(recvmsg == -1){
                perror("recv failed");
                break;
            }
        }

        if(strcmp(buf, "exit") == 0){
            printf("*thread %ld back to pool for disconnection\n", pthread_self());
            int closer = close(*fd);
            *fd = 0;
            if(closer == -1){
                perror("thread exit");
                exit(-1);
            }
            return;
        }

        printf("*thread %ld recv: %s\n", pthread_self(), buf);
        
        for(int i = 0; i < TASK; i++){
            if(confd[i] == 0) continue;
            int sendmsg = send(confd[i], buf, sizeof(buf), 0);
            if(sendmsg == -1){
                perror("sendmsg");
                break;
            }
        }
    }
}