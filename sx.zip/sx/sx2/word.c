# include <stdio.h>
# include <string.h>

# include "word.h"
int read_word(FILE* src, char* buf){
    if(fscanf(src, "%s", buf) == EOF) return EOF;
    int len = strlen(buf);
    // printf("read %s len:%d\n", buf, len);
    return len;
}