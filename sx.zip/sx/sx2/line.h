# ifndef LINE_H
# define LINE_H

# include <stdio.h>

struct line{
    char linebuf[41];
    int next;
};

void linePut(FILE* des, struct line* line);
void linePut2(FILE* des, struct line* line, int lineFull);
int lineAdd(struct line* line, char wordbuf[], int len);
#endif