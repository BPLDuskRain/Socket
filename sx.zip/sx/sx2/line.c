# include <stdio.h>
# include <string.h>

# include "line.h"
# define LINE 40
void linePut(FILE* des, struct line* line){
    memcpy(line->linebuf+39, "\n", 2);
    // printf("line:%s", line->linebuf);
    fprintf(des, "%s", line->linebuf);
}

void linePut2(FILE* des, struct line* line, int lineFull){
    for(int i = 0; i < LINE && lineFull > 0; ++i){
        if((line->linebuf)[i] == '\0'){
            // printf("insert blank\n");
            (line->linebuf)[i] = ' ';
            lineFull--;
        }
    }
    linePut(des, line);
}

int lineAdd(struct line* line, char wordbuf[], int len){
    if(line->next + len + 1 > LINE) {
        // printf("\treturn the less:%d\n", LINE - line->next);
        return LINE - line->next;//return space, value>=0
    }
    memcpy((line->linebuf)+line->next, wordbuf, len+1);
    line->next += len;
    memcpy((line->linebuf)+line->next, " ", 2);
    line->next++;
    // printf("\tadd %s\n", wordbuf);
    // printf("\tnext is %d\n",line->next);
    if(LINE-line->next == 0) return 0;
    else return -1;
}