# ifndef WORD_H
# define WORD_H

# include <stdio.h>

int read_word(FILE* src, char* buf);

#endif