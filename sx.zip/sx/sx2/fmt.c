# include <stdio.h>
# include <string.h>

# include "word.h"
# include "line.h"

# define LINE 40
int main(int argc, char* argv[]){
    char srcPath[50] = {0};
    char desPath[50] = {0};
    strcpy(srcPath, argv[1]);
    strcpy(desPath, argv[2]);
    FILE* src = fopen(srcPath, "r");
    FILE* des = fopen(desPath, "w");

    struct line line;
    memset(line.linebuf, 0, LINE);
    line.next = 0;
    int lineFull = -1;
        while(1){
        char wordbuf[20] = {0};
        int len;
        if(lineFull < 0){
            len = read_word(src, wordbuf);
            if(len == EOF){
                linePut(des, &line);
                break;
            }
            lineFull = lineAdd(&line, wordbuf, len);
        }
        if(lineFull > 0) {
            // printf("Line is full\n");
            linePut2(des, &line, lineFull);
            memset(line.linebuf, 0, 40);
            line.next = 0;
            lineFull = lineAdd(&line, wordbuf, len);
        }
        else if (lineFull == 0){
            // printf("Line is full\n");
            linePut(des, &line);
            memset(line.linebuf, 0, 40);
            line.next = 0;
            lineFull = -1;
        }
        
    }
    fclose(src);
    fclose(des);

    return 0;
}