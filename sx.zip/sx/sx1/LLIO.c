# include <stdio.h>
# include <stdlib.h>
# include <string.h>

# include "LinkList.h"
# define LINE 100

void change(Student* student){
    strcpy(student->id, "3");
    strcpy(student->name, "Hell");
    strcpy(student->password, "*****");
}

int main(){
    char srcpath[20] = "./data.csv";
    FILE* srcptr = fopen(srcpath, "r");
    
    char line[LINE]={0};
    fgets(line, LINE, srcptr);
    //printf("%s\n", line);
    char line1[LINE]={0};
    strcpy(line1,line);
    // for(int i = 0; i < LINE; ++i){
    //     if(line1[i]=='\n'){
    //         line1[i]='\0';
    //         break;
    //     }
    // }

    char id[10]={0};
    char name[10]={0};
    char password[10]={0};
    Linklist L = initList();
    Student student;

    while(fgets(line, LINE, srcptr) != NULL){
        int flag = 0;
        for(int i = 0; i < LINE; ++i){
            int tmp;
            if(line[i]==','||line[i]=='\n'){
                switch(flag){
                    case 0:
                    for(int j = 0; j < i; ++j){
                        id[j] = line[j];
                    }
                    tmp = i;
                    flag = 1;
                    break;
                    case 1:
                    for(int j = tmp+1; j < i; ++j){
                        name[j-tmp-1] = line[j];
                    }
                    tmp = i;
                    flag = 2;
                    break;
                    case 2:
                    for(int j = tmp+1; j < i; ++j){
                        password[j-tmp-1] = line[j];
                    }
                    tmp = i;
                    flag = 3;
                    break;
                }
                
            }
            
        }
        //printf("id:%s\nname:%s\npassword:%s\n", id,name,password);
        memset(line, 0, LINE);
        strcpy(student.id, id);
        strcpy(student.name, name);
        strcpy(student.password, password);
        memset(id, 0, 10);
        memset(name, 0, 10);
        memset(password, 0, 10);
        add_back(L, student);
        //traverse(L, print);
    }
    fclose(srcptr);

    change(&student);
    //add_back(L, student);
    //addNode(L, student);
    // traverse(L, print);
    // printf("\n");
    // delNode(L, search(L,3));
    traverse(L, print);
    printf("\n");
    Linklist N = insertSort(L);
    traverse(N, print);

    // char despath[20] = "./data.csv";
    // FILE* desptr = fopen(despath, "w");
    // fprintf(desptr, "%s",line1);
    // traverse_file(L, desptr, fileprint);
    
    // fclose(desptr);
    return 0;
}