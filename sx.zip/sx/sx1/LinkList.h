#ifndef LINKLIST_H
#define LINKLIST_H

#include <stdio.h>

typedef struct Student{
    char id[10];
    char name[10];
    char password[10];
}Student;

int idcmp(Student stu1, Student stu2);

typedef struct Node{
    Student data;
    struct Node* next;
}Node, *Linklist;

Linklist initList();
int isEmpty(Linklist L);
void destroyList(Linklist L);
int length(Linklist L);
void add_back(Linklist L, Student student);
void addNode(Linklist L, Node* p, Student student);
void delNode(Linklist L, Node* p);
Node* search(Linklist L, int id);
void traverse(Linklist L, void (*func)(Node*));
void print(Node* node);
void traverse_file(Linklist L, FILE* file, void (*func)(Node*, FILE*));
void fileprint(Node* node, FILE* filepath);
Linklist insertSort(Linklist L);
#endif