# include <stdio.h>
# include <stdlib.h>
# include <string.h>

# include "LinkList.h"

int idcmp(Student stu1, Student stu2){
    int id1 = atoi(stu1.id);
    int id2 = atoi(stu2.id);
    if(id1 > id2){
        return 1;
    }
    else if(id1 < id2){
        return -1;
    }
    else return 0;
}

Linklist initList(){
    Linklist L = (Linklist)malloc(sizeof(Node));
    L->next = NULL;
    return L;
}

int isEmpty(Linklist L){
    if(L->next == NULL){
        return 1;
    }
    else return 0;
}

void destroyList(Linklist L){
    if(isEmpty(L)){
        free(L);
    }
    else{
        Node* p = L->next;
        for(; p != NULL; ){
            Node* t = p;
            p = p->next;
            free(t);
        }
        free(L);
    }
}

int length(Linklist L){
    if(isEmpty(L)) return 0;
    Node* p = L->next;
    int count = 0;
    for(; p != NULL; p=p->next, count++);
    return count;
}

void add_back(Linklist L, Student student){
    Node* p = L;
    for(; p->next != NULL; p=p->next);
    Node* newNode = (Node*)malloc(sizeof(Node));
    p->next = newNode;
    newNode->next = NULL;
    newNode->data = student;
}

void addNode(Linklist L, Node* p, Student student){
    Node* node = (Node*)malloc(sizeof(Node));
    node->next = p->next;
    p->next = node;
    node->data = student;
}

void delNode(Linklist L, Node* del){
    if(isEmpty(L)) return;
    if(del == NULL) return;
    Node* p = L;
    for(; p->next != del; p=p->next);
    p->next = del->next;
    free(del);
    return;
}

Node* search(Linklist L, int id){
    if(isEmpty(L)) return NULL;
    Node* p = L->next;
    for(; p != NULL; p=p->next){
        if(atoi(p->data.id) == id){
            return p;
        }
    }
    return NULL;
}

void traverse(Linklist L, void (*func)(Node*)){
    if(isEmpty(L)) return;
    Node* p = L->next;
    for(; p != NULL; p=p->next){
        func(p);
    }
}

void print(Node* node){
    printf("Node: id %s, name %s, password %s\n", node->data.id, node->data.name, node->data.password);
}

void traverse_file(Linklist L, FILE* file, void (*func)(Node*, FILE*)){
    if(isEmpty(L)) return;
    Node* p = L->next;
    for(; p != NULL; p=p->next){
        func(p, file);
    }
}

void fileprint(Node* node, FILE* file){
    fprintf(file, "%s,%s,%s\n", node->data.id, node->data.name, node->data.password);
}

Linklist insertSort(Linklist L){
    if(isEmpty(L)) return NULL;
    Linklist N = initList();
    Node* p = L->next;
    int flag = 0;
    for(; p != NULL; p=p->next){
        flag = 0;
        if(isEmpty(N)){
            add_back(N, p->data);
            continue;
        }
        Node* q = N;
        for(; q->next != NULL; q=q->next){
            if(idcmp(p->data, q->next->data) == -1){
                addNode(L, q, p->data);
                flag = 1;
                break;
            }
        }
        if(flag == 0)add_back(N, p->data);
    }
    return N;
}
