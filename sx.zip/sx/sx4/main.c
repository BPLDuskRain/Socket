#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/wait.h>

// struct BufferPool{
//     char data[5][100];
//     int index[5];
//     int read;
//     int write;
//     int over;
// };

struct BufferPool{
    int data[5];
    int index[5];
    int read;
    int write;
    int over;
};

union semun
{
 int val;
 struct semid_ds *buf;
 unsigned short *arry;
};

void init_sem(int semid, int value){
    union semun sem_union;
    sem_union.val = value;
    semctl(semid, 0, SETVAL, sem_union);
}

void del_sem(int semid){
    semctl(semid, 0, IPC_RMID);
}

void sem_wait(int semid, struct sembuf* sembuffer){
    sembuffer->sem_num = 0;
    sembuffer->sem_op = -1;
    sembuffer->sem_flg = SEM_UNDO;
    semop(semid, sembuffer, 1);
}

void sem_signal(int semid, struct sembuf* sembuffer){
    sembuffer->sem_num = 0;
    sembuffer->sem_op = 1;
    sembuffer->sem_flg = SEM_UNDO;
    semop(semid, sembuffer, 1);
}

int main(){
    int semid = semget(21123, 1, IPC_CREAT);
    init_sem(semid, 1);

    int shmid = shmget(211, sizeof(struct BufferPool), IPC_CREAT | 0666);
    
    int flag = 0;
    int producer_pid[5] = {0};
    int consumer_pid[5] = {0};
    struct sembuf sembuffer;
    struct BufferPool* buffer = (struct BufferPool*)shmat(shmid, NULL, 0);
    memset(buffer, 0, sizeof(struct BufferPool));

    for(int i = 0; i < 5; i++){
        producer_pid[i] = fork();
        if (producer_pid[i] == 0){
            // sleep(1);
            flag = 1;
            printf("\tproducer %d born\n", getpid());
            
            break;
        }
        //printf("create a producer\n");
        consumer_pid[i] = fork();
        if (consumer_pid[i] == 0){
            flag = 2;
            printf("\t\tconsumer %d born\n", getpid());
            
            break;
        }
        //printf("create a consumer\n");

    }
    if(flag == 0){
        shmdt(buffer);
        for(int i = 0; i < 5; i++){
            waitpid(producer_pid[i], NULL, 0);
            waitpid(consumer_pid[i], NULL, 0);
            //printf("buffer[%d] = %d\n", i, buffer->data[i]);
        }
        shmctl(shmid, IPC_RMID, NULL);
        del_sem(semid);
        printf("main exit\n");
    }
    if(flag == 1){
        for(int i = 0; i < 2; i++){
            srand(getpid());
            int num = rand()%1000+80000;
            
            sem_wait(semid, &sembuffer);
            if(buffer->index[buffer->write] == 0){
                buffer->data[buffer->write] = num;
                printf("\tproducer %d write:%d to %d\n", getpid(), num, buffer->write);
                buffer->index[buffer->write] = 1;
                buffer->write = (buffer->write+1)%5;
            }
            buffer->over++;
            sem_signal(semid, &sembuffer);
        }
        shmdt(buffer);
        
        printf("\tproducer %d exit\n", getpid());
    }
    if(flag == 2){
        while(1){
            int num;
            
            sem_wait(semid, &sembuffer);
            // sleep(1);
            if(buffer->index[buffer->read] == 1){
                num = buffer->data[buffer->read];
                printf("\t\tconsumer %d read:%d from %d\n", getpid(), num, buffer->read);
                buffer->index[buffer->read] = 0;
                buffer->data[buffer->read] = 0;
                buffer->read = (buffer->read+1)%5;
                sem_signal(semid, &sembuffer);
                
            }else if(buffer->over == 10) {
                sem_signal(semid, &sembuffer);
                break;
            }
        }
        
        shmdt(buffer);
        printf("\t\tconsumer %d exit\n", getpid());
    }
    return 0;
}