#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bst.h"

int main(int argc, char* argv[]){
    FILE* rfp = fopen("./data.csv", "r");

    char buf[40] = {0};
    char title[40] = {0};
    char name[20] = {0};
    char phone[20] = {0};

    Tree BST = initTree();

    strcpy(title, fgets(buf, 40, rfp));
    while(fgets(buf, 40, rfp) != NULL){
        strcpy(name, strtok(buf, ","));
        // printf("name:%s\n", name);
        strcpy(phone, strtok(NULL, "\n"));
        // printf("phone:%s\n", phone);

        addNode(&BST, name, phone);
        memset(name, 0, 20);
        memset(phone, 0, 20);
    }
    fclose(rfp);
    // inorder(BST);
    // showInfo(search(BST, argv[1]));
    showInfo(search(BST, "Fraud"));
    // showInfo(search_parent(BST, (search(BST, "Fraud"))));

    addNode(&BST, "arona", "********");

    // inorder(BST);
    // printf("---\n");

    change(BST, search(BST, "arona"), "21425");

    // inorder(BST);
    // printf("---\n");

    delNode(BST, search(BST, "arona"));

    // inorder(BST);

    FILE* wfp = fopen("./data.csv", "w");
    fprintf(wfp, "%s", title);
    fprint(BST, wfp);
    fclose(wfp);
    return 0;
}