#ifndef BST_H
#define BST_H

#include <stdio.h>
#include <stdlib.h>

typedef struct Info{
    char name[20];
    char phone[20];
}Info;

typedef struct Node{
    struct Info* data;
    struct Node* lchild;
    struct Node* rchild;
}Node, *Tree;

Tree initTree();
Node* createNode(char name[], char phone[]);
void addNode(Tree* root, char name[], char phone[]);
void delNode(Tree root, Node* node);
void inorder(Tree root);
void fprint(Tree root, FILE* fp);
Node* search_parent(Tree root, Node* node);
Node* search(Tree root, char name[]);
void showInfo(Node* Node);
void change(Tree root, Node* node, char phone[]);
#endif