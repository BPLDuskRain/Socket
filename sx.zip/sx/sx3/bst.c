#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bst.h"

Tree initTree(){
    Tree* root = NULL;
}

Node* createNode(char name[], char phone[]){
    Node* node = (Node*)malloc(sizeof(Node));
    Info* info = (Info*)malloc(sizeof(Info));
    strcpy(info->name, name);
    strcpy(info->phone, phone);
    node->data = info;
    node->lchild = NULL;
    node->rchild = NULL;
    return node;
}

void addNode(Tree* root, char name[], char phone[]){
    if((*root) == NULL){
        (*root) = createNode(name, phone);
    }
    else if(strcmp(name, (*root)->data->name) < 0){
        addNode(&((*root)->lchild), name, phone);
    }
    else if(strcmp(name, (*root)->data->name) > 0){
        addNode(&((*root)->rchild), name, phone);
    }
    else return;
}

void delNode(Tree root, Node* node){
    if(root == NULL) return;
    Node* parent = search_parent(root, node);
    if(node->lchild == NULL && node->rchild == NULL){
        if(parent->lchild == node){
            parent->lchild = NULL;
        }else{
            parent->rchild = NULL;
        }
    }
    else if(node->lchild == NULL){
        if(parent->lchild == node){
            parent->lchild = node->rchild;
        }else{
            parent->rchild = node->rchild;
        }
    }
    else if(node->rchild == NULL){
        if(parent->lchild == node){
            parent->lchild = node->lchild;
        }else{
            parent->rchild = node->lchild;
        }
    }
    else{
        node->data = node->rchild->data;
        delNode(root, node->rchild);
    }
    free(node);
}

void inorder(Tree root){
    if(root == NULL) return;
    inorder(root->lchild);
    printf("node:name:%s,phone:%s\n", root->data->name, root->data->phone);
    inorder(root->rchild);
}

void fprint(Tree root, FILE* fp){
    if(root == NULL) return;
    fprintf(fp, "%s,%s\n", root->data->name, root->data->phone);
    fprint(root->lchild, fp);
    fprint(root->rchild, fp);
}

Node* search_parent(Tree root, Node* node){
    if(root == NULL) return NULL;
    if(root->lchild == node || root->rchild == node){
        return root;
    }
    else if(strcmp(node->data->name, root->data->name) < 0){
        return search_parent(root->lchild, node);
    }
    else{
        return search_parent(root->rchild, node);
    }
}

Node* search(Tree root, char name[]){
    if(root == NULL || strcmp(root->data->name, name) == 0) return root;
    if(strcmp(name, root->data->name) < 0){
        return search(root->lchild, name);
    }else{
        return search(root->rchild, name);
    }   
}

void showInfo(Node* node){
    printf("name: %s\n", node->data->name);
    printf("phone: %s\n", node->data->phone);
}

void change(Tree root, Node* node, char phone[]){
    if(node == NULL){
        printf("No such name\n");
        return;
    }
    else{
        strcpy(node->data->phone, phone);
    }
}

