# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <pthread.h>
# include <errno.h>

#define NUM 4

int chopstick[NUM] = {0};
pthread_t id[NUM];
pthread_t tid[NUM];

void think(pthread_t id){
    printf("philosopher %ld start thinking\n", id);
    srand(id);
    sleep(rand()%3);
    printf("philosopher %ld finish thinking\n", id);
}

void getChopstick1(pthread_t id){
    int l = EBUSY;
    int r = EBUSY;
    while(1){
        if(l == EBUSY){
            l = pthread_mutex_trylock(&(chopstick[id]));
            printf("\tphilosopher %ld try to GOT chopstick[%ld]\n", id, id);
            sleep(1);
        }
        else{
            printf("\tphilosopher %ld GOT chopstick[%ld]\n", id, id);
            printf("\tphilosopher %ld want to GOT chopstick[%ld]\n", id, (id+1)%NUM);
            int r = pthread_mutex_trylock(&(chopstick[(id+1)%NUM]));
            
            if(r == 0){
                printf("\tphilosopher %ld GOT chopstick[%ld]\n", id, (id+1)%NUM);
                break;
            }
            sleep(1);
        }
        
    }
}

void getChopstick2(pthread_t id){
    while(1){
        sleep(1);
        if(pthread_mutex_trylock(&(chopstick[id])) == 0){
            printf("\tphilosopher %ld GOT chopstick[%ld]\n", id, id);
        }
        else{
            continue;
        }
        if(pthread_mutex_trylock(&(chopstick[(id+1)%NUM])) == EBUSY){
            pthread_mutex_unlock(&(chopstick[id]));
            printf("\tphilosopher %ld GIVEUP chopstick[%ld]\n", id, id);
            
        }
        else{
            printf("\tphilosopher %ld GOT chopstick[%ld]\n", id, (id+1)%NUM);
            break;
        }
    }
}

void eat(pthread_t id){
    printf("\t\tphilosopher %ld start EATing\n", id);
    srand((unsigned int)tid);
    sleep(2);
    printf("\t\tphilosopher %ld finish EATing\n", id);
}

void giveupAll(pthread_t id){
    pthread_mutex_unlock(&(chopstick[id]));
    printf("\tphilosopher %ld GIVEUP chopstick[%ld]\n", id, id);
    pthread_mutex_unlock(&(chopstick[(id+1)%NUM]));
    printf("\tphilosopher %ld GIVEUP chopstick[%ld]\n", id, (id+1)%NUM);
}

void* thread_func(pthread_t id){
    pthread_t tid = pthread_self();
    think(id);
    getChopstick2(id);
    eat(id);
    giveupAll(id);
    // sleep(5);
    printf("philosopher %ld exit\n", id);
    pthread_exit(NULL);
}

int main(){
    for(int i = 0; i < NUM; i++){
        id[i] = i;
    }

    for(int i = 0; i < NUM; i++){
        pthread_create(&(tid[i]), NULL, thread_func, id[i]);
    }

    for(int i = 0; i < NUM; i++){
        pthread_mutex_init(&(chopstick[i]), NULL);
    }

    for(int i = 0; i < NUM; i++){
        pthread_join(tid[i], NULL);
        printf("destroy %d\n", i);
    }

    for(int i = 0; i < NUM; i++){
        pthread_mutex_destroy(&(tid[i]));
    }
    
    printf("main exit\n");
    return 0;
}